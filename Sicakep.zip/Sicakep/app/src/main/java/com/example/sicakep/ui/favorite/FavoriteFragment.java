package com.example.sicakep.ui.favorite;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sicakep.Catatan;
import com.example.sicakep.FavoriteAdapter;
import com.example.sicakep.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FavoriteFragment extends Fragment {

    private RecyclerView recyclerFavorite;
    private FavoriteAdapter favoriteAdapter;
    private List<Catatan> favoriteList;
    private EditText editTextSearchFavorite;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorite, container, false);

        recyclerFavorite = view.findViewById(R.id.recyclerFavorite);
        editTextSearchFavorite = view.findViewById(R.id.editTextSearchFavorite);

        favoriteList = new ArrayList<>();
        favoriteAdapter = new FavoriteAdapter(getContext(), favoriteList);

        recyclerFavorite.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerFavorite.setAdapter(favoriteAdapter);

        ambilDataFavoriteDariFirebase();

        editTextSearchFavorite.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterFavorite(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        return view;
    }

    private void ambilDataFavoriteDariFirebase() {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("notes").child(userId);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                favoriteList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Boolean favorite = dataSnapshot.child("favorite").getValue(Boolean.class);

                    if (favorite != null && favorite) {
                        String title = dataSnapshot.child("title").getValue(String.class);
                        String description = dataSnapshot.child("description").getValue(String.class);
                        String imageBase64 = dataSnapshot.child("imageBase64").getValue(String.class);
                        String kategori = dataSnapshot.child("kategori").getValue(String.class);

                        Catatan catatan = new Catatan(title, description, imageBase64, kategori);
                        catatan.setNoteId(dataSnapshot.getKey());
                        favoriteList.add(catatan);
                    }
                }
                favoriteAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Gagal mengambil data favorit", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void filterFavorite(String keyword) {
        List<Catatan> hasilFilter = new ArrayList<>();
        for (Catatan c : favoriteList) {
            if (c.getJudul().toLowerCase().contains(keyword.toLowerCase()) ||
                    c.getKeterangan().toLowerCase().contains(keyword.toLowerCase())) {
                hasilFilter.add(c);
            }
        }
        favoriteAdapter = new FavoriteAdapter(getContext(), hasilFilter);
        recyclerFavorite.setAdapter(favoriteAdapter);
    }
}
