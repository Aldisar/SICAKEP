package com.example.sicakep;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class AddNoteActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText etTitle, etDescription;
    private TextView tvDate, tvUserId;
    private ImageView ivNoteImage, ivFavorite, ivReminder, btnSave, btnBack;
    private Button btnPickImage;
    private Spinner spinnerKategori;
    private LinearLayout layoutReminder;

    private Uri imageUri;
    private Bitmap selectedBitmap;
    private boolean isFavorite = false;
    private String selectedKategori = "";
    private long reminderTime = 0;      // ⏰ TIME IN MILLISECONDS

    private DatabaseReference notesRef;
    private FirebaseUser currentUser;

    private String currentDate;
    private List<String> kategoriList = new ArrayList<>();
    private ArrayAdapter<String> adapterKategori;
    private String noteId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        // --- Inisialisasi View ---
        etTitle        = findViewById(R.id.etTitle);
        etDescription  = findViewById(R.id.etDescription);
        tvDate         = findViewById(R.id.tvDate);
        tvUserId       = findViewById(R.id.tvUserId);
        ivNoteImage    = findViewById(R.id.ivNoteImage);
        ivFavorite     = findViewById(R.id.ivFavorite);
        ivReminder     = findViewById(R.id.ivReminder);
        layoutReminder = findViewById(R.id.layoutReminder);
        btnSave        = findViewById(R.id.btnSave);
        btnBack        = findViewById(R.id.btnBack);
        btnPickImage   = findViewById(R.id.btnPickImage);
        spinnerKategori= findViewById(R.id.spinnerKategori);

        // --- Firebase & User ---
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        notesRef    = FirebaseDatabase.getInstance().getReference("notes");

        if (currentUser != null) {
            tvUserId.setText(currentUser.getDisplayName());
        }

        // Set tanggal hari ini
        currentDate = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(new Date());
        tvDate.setText(currentDate);

        // Setup spinner kategori
        setupKategoriSpinner();

        // --- Event Listeners ---
        tvDate.setOnClickListener(v -> showDatePicker());
        btnPickImage.setOnClickListener(v -> openImageChooser());

        ivFavorite.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            ivFavorite.setImageResource(isFavorite ? R.drawable.bintang_fill : R.drawable.bintang);
        });

        layoutReminder.setOnClickListener(v -> showDateTimePicker());

        btnSave.setOnClickListener(v -> {
            if (validateInput()) {
                saveNoteToDatabase();
            }
        });

        btnBack.setOnClickListener(v -> onBackPressed());
    }

    private void setupKategoriSpinner() {
        adapterKategori = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, kategoriList);
        adapterKategori.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerKategori.setAdapter(adapterKategori);

        // Ambil daftar kategori dari Firebase
        String userId = currentUser.getUid();
        DatabaseReference ref = FirebaseDatabase
                .getInstance()
                .getReference("kategori")
                .child(userId);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                kategoriList.clear();
                kategoriList.add("Tanpa Kategori");
                for (DataSnapshot ds : snapshot.getChildren()) {
                    String nama = ds.child("nama").getValue(String.class);
                    if (nama != null) kategoriList.add(nama);
                }
                adapterKategori.notifyDataSetChanged();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AddNoteActivity.this,
                        "Gagal memuat kategori", Toast.LENGTH_SHORT).show();
            }
        });

        spinnerKategori.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent,
                                                 View view,
                                                 int position,
                                                 long id) {
                selectedKategori = kategoriList.get(position);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        new DatePickerDialog(this,
                (view, year, month, day) -> {
                    calendar.set(year, month, day);
                    currentDate = new SimpleDateFormat("dd MMMM yyyy",
                            Locale.getDefault())
                            .format(calendar.getTime());
                    tvDate.setText(currentDate);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void showDateTimePicker() {
        Calendar calendar = Calendar.getInstance();
        new DatePickerDialog(this,
                (view, year, month, day) -> {
                    new TimePickerDialog(this,
                            (view1, hour, minute) -> {
                                calendar.set(year, month, day, hour, minute);
                                reminderTime = calendar.getTimeInMillis();
                                Toast.makeText(this,
                                        "Pengingat berhasil diatur!",
                                        Toast.LENGTH_SHORT).show();
                            },
                            calendar.get(Calendar.HOUR_OF_DAY),
                            calendar.get(Calendar.MINUTE),
                            true
                    ).show();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PICK_IMAGE_REQUEST &&
                res == RESULT_OK &&
                data != null && data.getData() != null) {
            imageUri = data.getData();
            try {
                selectedBitmap = MediaStore.Images.Media
                        .getBitmap(getContentResolver(), imageUri);
                ivNoteImage.setImageBitmap(selectedBitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean validateInput() {
        String title = etTitle.getText().toString().trim();
        String desc  = etDescription.getText().toString().trim();
        if (title.isEmpty()) {
            etTitle.setError("Judul wajib diisi");
            etTitle.requestFocus();
            return false;
        }
        if (desc.isEmpty()) {
            etDescription.setError("Deskripsi wajib diisi");
            etDescription.requestFocus();
            return false;
        }
        return true;
    }

    private void saveNoteToDatabase() {
        String title = etTitle.getText().toString().trim();
        String desc  = etDescription.getText().toString().trim();
        String uid   = currentUser != null ? currentUser.getUid() : "";
        String userName = currentUser != null
                ? currentUser.getDisplayName()
                : "";

        noteId = notesRef.child(uid).push().getKey();

        // Encode gambar ke Base64
        String imageBase64 = "";
        if (selectedBitmap != null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            selectedBitmap
                    .compress(Bitmap.CompressFormat.JPEG, 50, baos);
            imageBase64 = Base64
                    .encodeToString(baos.toByteArray(), Base64.DEFAULT);
        }

        Map<String, Object> note = new HashMap<>();
        note.put("id",          noteId);
        note.put("title",       title);
        note.put("description", desc);
        note.put("date",        currentDate);
        note.put("favorite",    isFavorite);
        note.put("kategori",    selectedKategori);
        note.put("imageBase64", imageBase64);
        note.put("reminderTime", reminderTime);  // ⏰
        note.put("userId",      uid);
        note.put("userName",    userName);

        notesRef.child(uid).child(noteId)
                .setValue(note)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this,
                            "Catatan berhasil disimpan!",
                            Toast.LENGTH_SHORT).show();
                    finish();  // Kembali ke HomeFragment
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this,
                                "Gagal menyimpan catatan",
                                Toast.LENGTH_SHORT).show()
                );
    }
}
