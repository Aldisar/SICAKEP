package com.example.sicakep.ui.schedule;

import androidx.lifecycle.ViewModel;

public class ScheduleViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}