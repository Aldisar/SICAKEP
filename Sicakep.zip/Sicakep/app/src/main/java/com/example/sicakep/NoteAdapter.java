package com.example.sicakep;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private ArrayList<Note> notes;
    private OnNoteActionListener listener;

    public interface OnNoteActionListener {
        void onNoteClick(int position);
        void onEditClick(int position);
        void onDeleteClick(int position);
    }

    public NoteAdapter(ArrayList<Note> notes, OnNoteActionListener listener) {
        this.notes = notes;
        this.listener = listener;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_note, parent, false);
        return new NoteViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note note = notes.get(position);
        holder.judul.setText(note.getJudul());
        holder.keterangan.setText(note.getKeterangan());
        holder.gambar.setImageResource(note.getGambar());

        holder.itemView.setOnClickListener(v -> listener.onNoteClick(position));
        holder.btnEdit.setOnClickListener(v -> listener.onEditClick(position));
        holder.btnHapus.setOnClickListener(v -> listener.onDeleteClick(position));
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public static class NoteViewHolder extends RecyclerView.ViewHolder {
        TextView judul, keterangan;
        ImageView gambar, btnEdit, btnHapus;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            judul = itemView.findViewById(R.id.textJudul);
            keterangan = itemView.findViewById(R.id.textKeterangan);
            gambar = itemView.findViewById(R.id.imageNote);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnHapus = itemView.findViewById(R.id.btnHapus);
        }
    }
}
