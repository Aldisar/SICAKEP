package com.example.sicakep;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    private TextView textJudul, textKeterangan;
    private ImageView imagePreview;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        textJudul = findViewById(R.id.textDetailJudul);
        textKeterangan = findViewById(R.id.textDetailKeterangan);
        imagePreview = findViewById(R.id.imageDetail);

        // Ambil data dari Intent
        Note note = getIntent().getParcelableExtra("note");

        if (note != null) {
            textJudul.setText(note.getJudul());
            textKeterangan.setText(note.getKeterangan());
            imagePreview.setImageResource(note.getGambar());
        }
    }
}
