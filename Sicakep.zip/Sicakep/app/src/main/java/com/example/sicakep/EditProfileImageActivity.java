package com.example.sicakep;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class EditProfileImageActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView ivProfileImage;
    private Button btnChangeImage, btnCancel, btnSaveImage;
    private Uri imageUri;
    private String base64Image;

    private DatabaseReference userRef;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile_image);

        ivProfileImage = findViewById(R.id.ivProfileImage);
        btnChangeImage = findViewById(R.id.btnChangeImage);
        btnCancel = findViewById(R.id.btnCancel);
        btnSaveImage = findViewById(R.id.btnSaveImage);

        // Ambil user saat ini
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            userId = user.getUid();
            userRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

            // Tampilkan gambar lama jika ada
            userRef.child("profileImage").get().addOnSuccessListener(snapshot -> {
                String base64 = snapshot.getValue(String.class);
                if (base64 != null && !base64.isEmpty()) {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    ivProfileImage.setImageBitmap(bitmap);
                }
            });
        }

        // Tombol ganti gambar
        btnChangeImage.setOnClickListener(v -> openFileChooser());

        // Tombol simpan
        btnSaveImage.setOnClickListener(v -> {
            if (base64Image != null) {
                userRef.child("profileImage").setValue(base64Image)
                        .addOnSuccessListener(unused -> {
                            Toast.makeText(this, "Gambar profil berhasil disimpan!", Toast.LENGTH_SHORT).show();
                            finish(); // Kembali ke Fragment Account
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(this, "Gagal menyimpan gambar.", Toast.LENGTH_SHORT).show();
                        });
            } else {
                Toast.makeText(this, "Silakan pilih gambar terlebih dahulu.", Toast.LENGTH_SHORT).show();
            }
        });

        // Tombol cancel
        btnCancel.setOnClickListener(v -> finish());
    }

    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            ivProfileImage.setImageURI(imageUri);

            try {
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                base64Image = encodeImageToBase64(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String encodeImageToBase64(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos); // Kompres 50%
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }
}
