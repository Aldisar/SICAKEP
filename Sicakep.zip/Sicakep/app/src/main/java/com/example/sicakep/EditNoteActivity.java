package com.example.sicakep;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class EditNoteActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText etTitle, etDescription;
    private TextView tvDate;
    private ImageView ivNoteImage, ivFavorite, ivReminder, btnSave, btnBack;
    private Button btnPickImage;
    private Spinner spinnerKategori;
    private LinearLayout layoutReminder;

    private Uri imageUri;
    private Bitmap selectedBitmap;
    private String noteId;
    private String currentDate;
    private String selectedKategori = "Tanpa Kategori";
    private boolean isFavorite = false;
    private String existingImageBase64 = "";
    private long reminderTime = 0;

    private List<String> kategoriList = new ArrayList<>();
    private ArrayAdapter<String> adapterKategori;

    private DatabaseReference notesRef;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);

        etTitle = findViewById(R.id.etTitle);
        etDescription = findViewById(R.id.etDescription);
        tvDate = findViewById(R.id.tvDate);
        ivNoteImage = findViewById(R.id.ivNoteImage);
        ivFavorite = findViewById(R.id.ivFavorite);
        ivReminder = findViewById(R.id.ivReminder);
        btnSave = findViewById(R.id.btnSave);
        btnBack = findViewById(R.id.btnBack);
        btnPickImage = findViewById(R.id.btnPickImage);
        spinnerKategori = findViewById(R.id.spinnerKategori);
        layoutReminder = findViewById(R.id.layoutReminder);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        notesRef = FirebaseDatabase.getInstance().getReference("notes");
        noteId = getIntent().getStringExtra("noteId");

        setupSpinnerKategori();
        loadNoteData();

        tvDate.setOnClickListener(v -> showDatePicker());
        layoutReminder.setOnClickListener(v -> showDateTimePicker());
        btnPickImage.setOnClickListener(v -> openImageChooser());
        btnBack.setOnClickListener(v -> onBackPressed());
        btnSave.setOnClickListener(v -> updateNote());

        ivFavorite.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            ivFavorite.setImageResource(isFavorite ? R.drawable.bintang_fill : R.drawable.bintang);
        });
    }

    private void setupSpinnerKategori() {
        adapterKategori = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategoriList);
        adapterKategori.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerKategori.setAdapter(adapterKategori);

        String uid = currentUser.getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("kategori").child(uid);
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                kategoriList.clear();
                kategoriList.add("Tanpa Kategori");
                for (DataSnapshot ds : snapshot.getChildren()) {
                    String nama = ds.child("nama").getValue(String.class);
                    if (nama != null) kategoriList.add(nama);
                }
                adapterKategori.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

        spinnerKategori.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedKategori = kategoriList.get(position);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void loadNoteData() {
        if (currentUser != null && noteId != null) {
            notesRef.child(currentUser.getUid()).child(noteId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        etTitle.setText(snapshot.child("title").getValue(String.class));
                        etDescription.setText(snapshot.child("description").getValue(String.class));
                        currentDate = snapshot.child("date").getValue(String.class);
                        tvDate.setText(currentDate);

                        existingImageBase64 = snapshot.child("imageBase64").getValue(String.class);
                        isFavorite = Boolean.TRUE.equals(snapshot.child("favorite").getValue(Boolean.class));
                        reminderTime = snapshot.child("reminderTime").getValue(Long.class) != null ?
                                snapshot.child("reminderTime").getValue(Long.class) : 0;

                        ivFavorite.setImageResource(isFavorite ? R.drawable.bintang_fill : R.drawable.bintang);

                        if (existingImageBase64 != null && !existingImageBase64.isEmpty()) {
                            byte[] imageBytes = Base64.decode(existingImageBase64, Base64.DEFAULT);
                            ivNoteImage.setImageBitmap(BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length));
                        }

                        String kategori = snapshot.child("kategori").getValue(String.class);
                        if (kategori != null) selectedKategori = kategori;
                        spinnerKategori.post(() -> {
                            int index = kategoriList.indexOf(selectedKategori);
                            if (index >= 0) spinnerKategori.setSelection(index);
                        });
                    }
                }

                @Override public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(EditNoteActivity.this, "Gagal memuat catatan", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(this,
                (view, year, month, day) -> {
                    calendar.set(year, month, day);
                    currentDate = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(calendar.getTime());
                    tvDate.setText(currentDate);
                },
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }

    private void showDateTimePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog dateDialog = new DatePickerDialog(this,
                (view, year, month, day) -> {
                    TimePickerDialog timeDialog = new TimePickerDialog(this,
                            (view1, hour, minute) -> {
                                calendar.set(year, month, day, hour, minute);
                                reminderTime = calendar.getTimeInMillis();
                                Toast.makeText(this, "Waktu pengingat diperbarui", Toast.LENGTH_SHORT).show();
                            },
                            calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true);
                    timeDialog.show();
                },
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        dateDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            try {
                selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                ivNoteImage.setImageBitmap(selectedBitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateNote() {
        String title = etTitle.getText().toString().trim();
        String desc = etDescription.getText().toString().trim();

        if (title.isEmpty() || desc.isEmpty()) {
            Toast.makeText(this, "Judul dan Deskripsi wajib diisi", Toast.LENGTH_SHORT).show();
            return;
        }

        String imageBase64 = existingImageBase64;
        if (selectedBitmap != null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            selectedBitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
            imageBase64 = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
        }

        Map<String, Object> updatedNote = new HashMap<>();
        updatedNote.put("title", title);
        updatedNote.put("description", desc);
        updatedNote.put("date", currentDate);
        updatedNote.put("kategori", selectedKategori);
        updatedNote.put("favorite", isFavorite);
        updatedNote.put("imageBase64", imageBase64);
        updatedNote.put("reminderTime", reminderTime);

        notesRef.child(currentUser.getUid()).child(noteId).updateChildren(updatedNote)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Catatan berhasil diperbarui", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Gagal memperbarui catatan", Toast.LENGTH_SHORT).show());
    }
}
