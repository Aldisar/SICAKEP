package com.example.sicakep;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.sicakep.ui.favorite.FavoriteFragment;
import com.example.sicakep.ui.Account.AccountFragment;
import com.example.sicakep.ui.schedule.ScheduleFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    private boolean isGuest = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ambil status isGuest dari intent
        if (getIntent().hasExtra("isGuest")) {
            isGuest = getIntent().getBooleanExtra("isGuest", true);
        }

        bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Tampilkan fragment default (NoteFragment) dan kirim isGuest
        loadNoteFragment();

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                Fragment selectedFragment = null;

                if (id == R.id.navigation_home) {
                    loadNoteFragment(); // Khusus NoteFragment, kirim isGuest
                    return true;
                } else if (id == R.id.navigation_schedule) {
                    if (isGuest) {
                        Toast.makeText(MainActivity.this, "Fitur ini hanya tersedia untuk pengguna terdaftar.", Toast.LENGTH_SHORT).show();
                        return false;
                    }
                    selectedFragment = new ScheduleFragment();
                } else if (id == R.id.navigation_favorite) {
                    if (isGuest) {
                        Toast.makeText(MainActivity.this, "Fitur ini hanya tersedia untuk pengguna terdaftar.", Toast.LENGTH_SHORT).show();
                        return false;
                    }
                    selectedFragment = new FavoriteFragment();
                } else if (id == R.id.navigation_account) {
                    if (isGuest) {
                        startActivity(new Intent(MainActivity.this, RegisterActivity.class));
                        return false;
                    }
                    selectedFragment = new AccountFragment();
                }

                if (selectedFragment != null) {
                    loadFragment(selectedFragment);
                    return true;
                }

                return false;
            }
        });
    }

    private void loadNoteFragment() {
        NoteFragment noteFragment = new NoteFragment();
        Bundle bundle = new Bundle();
        bundle.putBoolean("isGuest", isGuest);
        noteFragment.setArguments(bundle);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, noteFragment)
                .commit();
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
