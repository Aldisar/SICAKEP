package com.example.sicakep.ui.home;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sicakep.AddNoteActivity;
import com.example.sicakep.Catatan;
import com.example.sicakep.CatatanAdapter;
import com.example.sicakep.EditNoteActivity;
import com.example.sicakep.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.util.HashSet;
import java.util.Set;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private CatatanAdapter catatanAdapter;
    private List<Catatan> catatanList;
    private Spinner spinnerKategori;
    private List<String> kategoriList;
    private ArrayAdapter<String> adapterKategori;
    private EditText editTextSearch;
    private BroadcastReceiver popupReceiver;
    private LocalBroadcastManager localBroadcastManager;

    private Set<String> reminderShownSet = new HashSet<>();  // Menyimpan catatan yang sudah ditampilkan pengingatnya

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recyclerCatatan);
        spinnerKategori = view.findViewById(R.id.spinnerKategori);
        editTextSearch = view.findViewById(R.id.editTextSearch);

        kategoriList = new ArrayList<>();
        adapterKategori = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, kategoriList);
        adapterKategori.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerKategori.setAdapter(adapterKategori);

        catatanList = new ArrayList<>();
        catatanAdapter = new CatatanAdapter(getContext(), catatanList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(catatanAdapter);

        ambilKategoriDariFirebase();
        ambilCatatanDariFirebase();
        setupSwipeToEditOrDelete();

        spinnerKategori.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selected = kategoriList.get(position);
                if ("Tambah Kategori...".equals(selected)) {
                    tampilkanDialogTambahKategori();
                } else {
                    ambilCatatanDariFirebase();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        ImageView imgTambah = view.findViewById(R.id.imgTambah);
        imgTambah.setOnClickListener(v -> startActivity(new Intent(getContext(), AddNoteActivity.class)));

        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterCatatan(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        mintaIzinNotifikasi();
        setupBroadcastReceiver();

        return view;
    }

    private void mintaIzinNotifikasi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
            }
        }
    }

    private void setupBroadcastReceiver() {
        localBroadcastManager = LocalBroadcastManager.getInstance(requireContext());
        popupReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // Handle reminders here
                checkForReminders();
            }
        };

        IntentFilter filter = new IntentFilter("com.example.sicakep.NOTIF_HOME");
        localBroadcastManager.registerReceiver(popupReceiver, filter);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (popupReceiver != null) {
            try {
                localBroadcastManager.unregisterReceiver(popupReceiver);
            } catch (Exception ignored) {
            }
        }
    }

    private void ambilKategoriDariFirebase() {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("kategori").child(userId);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                kategoriList.clear();
                kategoriList.add("Semua");
                for (DataSnapshot ds : snapshot.getChildren()) {
                    String nama = ds.child("nama").getValue(String.class);
                    if (nama != null) {
                        kategoriList.add(nama);
                    }
                }
                kategoriList.add("Tambah Kategori...");
                adapterKategori.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Gagal mengambil kategori", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void tampilkanDialogTambahKategori() {
        EditText input = new EditText(getContext());
        input.setHint("Masukkan nama kategori");
        new AlertDialog.Builder(requireContext())
                .setTitle("Tambah Kategori")
                .setView(input)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String baru = input.getText().toString().trim();
                    if (!baru.isEmpty()) {
                        simpanKategoriKeFirebase(baru);
                    } else {
                        Toast.makeText(getContext(), "Kategori tidak boleh kosong", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void simpanKategoriKeFirebase(String nama) {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("kategori").child(userId);
        String key = ref.push().getKey();
        if (key != null) {
            ref.child(key).child("nama").setValue(nama)
                    .addOnSuccessListener(aVoid -> Toast.makeText(getContext(), "Kategori ditambahkan", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> Toast.makeText(getContext(), "Gagal menambahkan kategori", Toast.LENGTH_SHORT).show());
        }
    }

    private void ambilCatatanDariFirebase() {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("notes").child(userId);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                catatanList.clear();
                String selectedKategori = spinnerKategori.getSelectedItem() != null ? spinnerKategori.getSelectedItem().toString() : "Semua";

                for (DataSnapshot ds : snapshot.getChildren()) {
                    String title = ds.child("title").getValue(String.class);
                    String description = ds.child("description").getValue(String.class);
                    String image = ds.child("imageBase64").getValue(String.class);
                    String kategori = ds.child("kategori").getValue(String.class);
                    long reminderTime = ds.child("reminderTime").getValue(Long.class) != null ? ds.child("reminderTime").getValue(Long.class) : 0;

                    if (title != null && description != null && kategori != null) {
                        if ("Semua".equals(selectedKategori) || selectedKategori.equalsIgnoreCase(kategori)) {
                            Catatan catatan = new Catatan(title, description, image, kategori);
                            catatan.setNoteId(ds.getKey());
                            catatan.setReminderTime(reminderTime);
                            catatanList.add(catatan);
                        }
                    }
                }
                catatanAdapter.notifyDataSetChanged();
                checkForReminders();  // Mengecek pengingat setelah mengambil data
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Gagal mengambil catatan", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkForReminders() {
        long currentTime = System.currentTimeMillis();
        long margin = 60000; // toleransi 1 menit (dalam ms) untuk mendeteksi reminder yang "baru saja terjadi"

        for (Catatan catatan : catatanList) {
            long reminderTime = catatan.getReminderTime();
            String noteId = catatan.getNoteId();

            if (reminderTime > 0 &&
                    Math.abs(reminderTime - currentTime) <= margin &&
                    !reminderShownSet.contains(noteId)) {

                showReminderDialog(catatan);
                reminderShownSet.add(noteId);
            }
        }
    }

    private void showReminderDialog(Catatan catatan) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Pengingat Catatan")
                .setMessage("Catatan penting: " + catatan.getJudul() + "\n" + catatan.getKeterangan())
                .setPositiveButton("OK", null)
                .show();
    }

    private void filterCatatan(String keyword) {
        List<Catatan> hasilFilter = new ArrayList<>();
        String selectedKategori = spinnerKategori.getSelectedItem() != null ? spinnerKategori.getSelectedItem().toString() : "Semua";

        for (Catatan c : catatanList) {
            boolean cocokKategori = selectedKategori.equals("Semua") || selectedKategori.equalsIgnoreCase(c.getKategori());
            boolean cocokKeyword = c.getJudul().toLowerCase().contains(keyword.toLowerCase()) ||
                    c.getKeterangan().toLowerCase().contains(keyword.toLowerCase());
            if (cocokKategori && cocokKeyword) {
                hasilFilter.add(c);
            }
        }
        catatanAdapter.setFilteredList(hasilFilter);
    }

    private void setupSwipeToEditOrDelete() {
        ItemTouchHelper.SimpleCallback swipeCallback = new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                Catatan catatan = catatanAdapter.getItemAt(position);
                if (catatan == null || catatan.getNoteId() == null) {
                    catatanAdapter.notifyItemChanged(position);
                    return;
                }

                if (direction == ItemTouchHelper.LEFT) {
                    // Tampilkan konfirmasi hapus
                    new AlertDialog.Builder(requireContext())
                            .setTitle("Konfirmasi Hapus")
                            .setMessage("Apakah Anda yakin ingin menghapus catatan ini?")
                            .setPositiveButton("Hapus", (dialog, which) -> {
                                // Jika setuju, hapus di Firebase
                                String userId = FirebaseAuth.getInstance()
                                        .getCurrentUser().getUid();
                                DatabaseReference ref = FirebaseDatabase.getInstance()
                                        .getReference("notes")
                                        .child(userId)
                                        .child(catatan.getNoteId());
                                ref.removeValue()
                                        .addOnSuccessListener(aVoid -> {
                                            Toast.makeText(getContext(),
                                                            "Catatan dihapus", Toast.LENGTH_SHORT)
                                                    .show();
                                            catatanAdapter.notifyItemRemoved(position);
                                        })
                                        .addOnFailureListener(e -> {
                                            Toast.makeText(getContext(),
                                                            "Gagal menghapus", Toast.LENGTH_SHORT)
                                                    .show();
                                            catatanAdapter.notifyItemChanged(position);
                                        });
                            })
                            .setNegativeButton("Batal", (dialog, which) -> {
                                // Jika batal, kembalikan item
                                catatanAdapter.notifyItemChanged(position);
                            })
                            .setOnCancelListener(dialog -> {
                                // Jika dialog ditutup dengan back/home
                                catatanAdapter.notifyItemChanged(position);
                            })
                            .show();

                } else {
                    // Swipe kanan → Edit
                    Intent intent = new Intent(getContext(), EditNoteActivity.class);
                    intent.putExtra("noteId", catatan.getNoteId());
                    startActivity(intent);
                    catatanAdapter.notifyItemChanged(position);
                }
            }

            @Override
            public void onChildDraw(@NonNull Canvas c,
                                    @NonNull RecyclerView recyclerView,
                                    @NonNull RecyclerView.ViewHolder viewHolder,
                                    float dX, float dY,
                                    int actionState, boolean isCurrentlyActive) {
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY,
                        actionState, isCurrentlyActive);

                View itemView = viewHolder.itemView;
                Paint backgroundPaint = new Paint();
                Paint textPaint = new Paint();
                textPaint.setColor(Color.WHITE);
                textPaint.setTextSize(40);
                textPaint.setFakeBoldText(true);

                if (dX > 0) { // Swipe kanan → Edit
                    backgroundPaint.setColor(Color.parseColor("#D1C4E9"));
                    c.drawRect(itemView.getLeft(), itemView.getTop(),
                            dX, itemView.getBottom(), backgroundPaint);
                    c.drawText("Edit",
                            itemView.getLeft() + 50,
                            itemView.getTop() + (itemView.getHeight() / 2f) + 15,
                            textPaint);
                } else if (dX < 0) { // Swipe kiri → Hapus
                    backgroundPaint.setColor(Color.parseColor("#FF8A80"));
                    c.drawRect(itemView.getRight() + dX, itemView.getTop(),
                            itemView.getRight(), itemView.getBottom(),
                            backgroundPaint);
                    float textWidth = textPaint.measureText("Hapus");
                    c.drawText("Hapus",
                            itemView.getRight() - textWidth - 50,
                            itemView.getTop() + (itemView.getHeight() / 2f) + 15,
                            textPaint);
                }
            }
        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(swipeCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }
}