package com.example.sicakep;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class EditProfileActivity extends AppCompatActivity {

    private EditText etFullname, etUsername, etEmail;
    private Button btnSaveProfile;
    private FirebaseDatabase database;
    private FirebaseAuth mAuth;
    private DatabaseReference usersRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbarEditProfile);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Menampilkan tombol kembali
            getSupportActionBar().setDisplayShowTitleEnabled(false); // Menyembunyikan judul default
        }

        etFullname = findViewById(R.id.etFullname);
        etUsername = findViewById(R.id.etUsername);
        etEmail = findViewById(R.id.etEmail);
        btnSaveProfile = findViewById(R.id.btnSaveProfile);

        database = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();

        // Mendapatkan referensi ke node "users"
        usersRef = database.getReference("users");

        // Isi field dengan data dari intent kalau ada
        Intent intent = getIntent();
        etFullname.setText(intent.getStringExtra("fullname"));
        etUsername.setText(intent.getStringExtra("username"));
        etEmail.setText(intent.getStringExtra("email"));

        btnSaveProfile.setOnClickListener(v -> {
            String fullname = etFullname.getText().toString().trim();
            String username = etUsername.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            if (fullname.isEmpty() || username.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                return;
            }

            String uid = mAuth.getCurrentUser().getUid();

            // Menyimpan data ke Realtime Database
            usersRef.child(uid).child("fullname").setValue(fullname);
            usersRef.child(uid).child("username").setValue(username);
            usersRef.child(uid).child("email").setValue(email)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Profil berhasil disimpan", Toast.LENGTH_SHORT).show();

                        // Kirim kembali ke fragment
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("username", username);
                        resultIntent.putExtra("fullname", fullname);
                        resultIntent.putExtra("email", email);
                        setResult(RESULT_OK, resultIntent);
                        finish(); // Menutup EditProfileActivity
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Gagal menyimpan ke Realtime Database", Toast.LENGTH_SHORT).show();
                    });
        });
    }

    @Override
    public void onBackPressed() {
        // Kirim data kembali ke fragment AccountFragment jika ada perubahan
        Intent resultIntent = new Intent();
        resultIntent.putExtra("username", etUsername.getText().toString());
        resultIntent.putExtra("fullname", etFullname.getText().toString());
        resultIntent.putExtra("email", etEmail.getText().toString());
        setResult(RESULT_OK, resultIntent);

        super.onBackPressed(); // Menutup activity
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed(); // Supaya tombol back di toolbar juga kirim data dan kembali
        return true;
    }
}
