package com.example.sicakep;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

public class ViewNoteActivity extends AppCompatActivity {

    private ImageView btnBack, ivNoteImage;
    private TextView tvUserId, tvTitle, tvDate, tvDescription;

    private String noteId;
    private DatabaseReference noteRef;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_note);

        btnBack = findViewById(R.id.btnBack);
        ivNoteImage = findViewById(R.id.ivNoteImage);
        tvUserId = findViewById(R.id.tvUserId);
        tvTitle = findViewById(R.id.tvTitle);
        tvDate = findViewById(R.id.tvDate);
        tvDescription = findViewById(R.id.tvDescription);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        noteId = getIntent().getStringExtra("noteId");

        if (currentUser == null || noteId == null) {
            Toast.makeText(this, "User tidak login atau noteId tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvUserId.setText(currentUser.getUid());

        btnBack.setOnClickListener(v -> finish());

        noteRef = FirebaseDatabase.getInstance()
                .getReference("notes")
                .child(currentUser.getUid())
                .child(noteId);

        loadNoteData();
    }

    private void loadNoteData() {
        noteRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    Toast.makeText(ViewNoteActivity.this, "Catatan tidak ditemukan", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }

                String title = snapshot.child("title").getValue(String.class);
                String description = snapshot.child("description").getValue(String.class);
                String date = snapshot.child("date").getValue(String.class);
                String imageBase64 = snapshot.child("imageBase64").getValue(String.class);

                tvTitle.setText(title != null ? title : "(No Title)");
                tvDescription.setText(description != null ? description : "(No Description)");
                tvDate.setText(date != null ? date : "(No Date)");

                if (imageBase64 != null && !imageBase64.isEmpty()) {
                    byte[] decoded = Base64.decode(imageBase64, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                    ivNoteImage.setImageBitmap(bitmap);
                } else {
                    ivNoteImage.setImageResource(R.drawable.ic_placeholder);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ViewNoteActivity.this, "Gagal memuat catatan", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
