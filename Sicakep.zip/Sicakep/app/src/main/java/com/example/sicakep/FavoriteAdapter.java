package com.example.sicakep;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder> {

    private Context context;
    private List<Catatan> favoriteList;

    public FavoriteAdapter(Context context, List<Catatan> favoriteList) {
        this.context = context;
        this.favoriteList = favoriteList;
    }

    @NonNull
    @Override
    public FavoriteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_catatan_favorite, parent, false);
        return new FavoriteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteViewHolder holder, int position) {
        Catatan catatan = favoriteList.get(position);
        holder.tvTitle.setText(catatan.getJudul());

        // Batasin keterangan jadi 2 kata
        String[] words = catatan.getKeterangan().split("\\s+");
        if (words.length > 2) {
            holder.tvDescription.setText(words[0] + " " + words[1] + "...");
        } else {
            holder.tvDescription.setText(catatan.getKeterangan());
        }

        // Decode Base64 image
        String base64Image = catatan.getGambarBase64();
        if (base64Image != null && !base64Image.isEmpty()) {
            try {
                byte[] decodedBytes = Base64.decode(base64Image, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                holder.ivNoteImage.setImageBitmap(bitmap);
            } catch (Exception e) {
                holder.ivNoteImage.setImageResource(R.drawable.ic_placeholder);
            }
        } else {
            holder.ivNoteImage.setImageResource(R.drawable.ic_placeholder);
        }

        // Tombol lihat catatan
        holder.btnLihat.setOnClickListener(v -> {
            Intent intent = new Intent(context, ViewNoteActivity.class);
            intent.putExtra("noteId", catatan.getNoteId());
            context.startActivity(intent);
        });

        // ❗ Klik bintang: hapus dari favorit
        holder.ivFavoriteIcon.setOnClickListener(v -> {
            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DatabaseReference noteRef = FirebaseDatabase.getInstance()
                    .getReference("notes")
                    .child(userId)
                    .child(catatan.getNoteId());

            // Update favorite = false di database
            noteRef.child("favorite").setValue(false)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(context, "Dihapus dari Favorit", Toast.LENGTH_SHORT).show();
                        // Hapus dari list lokal juga
                        favoriteList.remove(position);
                        notifyItemRemoved(position);
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(context, "Gagal menghapus favorit", Toast.LENGTH_SHORT).show();
                    });
        });
    }

    @Override
    public int getItemCount() {
        return favoriteList.size();
    }

    static class FavoriteViewHolder extends RecyclerView.ViewHolder {
        ImageView ivFavoriteIcon, ivNoteImage;
        TextView tvTitle, tvDescription;
        Button btnLihat;

        FavoriteViewHolder(@NonNull View itemView) {
            super(itemView);
            ivFavoriteIcon = itemView.findViewById(R.id.ivFavoriteIcon);
            ivNoteImage = itemView.findViewById(R.id.ivNoteImage);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            btnLihat = itemView.findViewById(R.id.btnLihat);
        }
    }
}
