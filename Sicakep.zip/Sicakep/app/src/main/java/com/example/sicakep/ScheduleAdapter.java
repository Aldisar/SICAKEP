package com.example.sicakep;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ViewHolder> {

    private Context context;
    private List<Catatan> reminderList;

    public ScheduleAdapter(Context context, List<Catatan> reminderList) {
        this.context = context;
        this.reminderList = reminderList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_schedule, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Catatan catatan = reminderList.get(position);
        holder.tvTitle.setText(catatan.getJudul());
        holder.tvKategori.setText("Kategori: " + catatan.getKategori());

        // Reminder time
        if (catatan.getReminderTime() > 0) {
            String dateTime = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                    .format(new Date(catatan.getReminderTime()));
            holder.tvReminderTime.setText(dateTime);

            // Tentukan status
            long currentTime = System.currentTimeMillis();
            if (catatan.getReminderTime() >= currentTime) {
                holder.statusText.setText("Akan Datang");
                holder.statusText.setTextColor(Color.parseColor("#2196F3")); // Biru
            } else {
                holder.statusText.setText("Riwayat");
                holder.statusText.setTextColor(Color.GRAY); // Abu-abu
            }
        } else {
            holder.tvReminderTime.setText("-");
            holder.statusText.setText("Tidak Ada");
            holder.statusText.setTextColor(Color.DKGRAY);
        }

        // Decode Base64 image
        if (catatan.getGambarBase64() != null && !catatan.getGambarBase64().isEmpty()) {
            byte[] decodedBytes = Base64.decode(catatan.getGambarBase64(), Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
            holder.ivNoteImage.setImageBitmap(bitmap);
        } else {
            holder.ivNoteImage.setImageResource(R.drawable.placeholder_image); // default image
        }
    }

    @Override
    public int getItemCount() {
        return reminderList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvReminderTime, tvKategori, statusText;
        ImageView ivNoteImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvReminderTime = itemView.findViewById(R.id.tvReminderTime);
            tvKategori = itemView.findViewById(R.id.tvKategori);
            statusText = itemView.findViewById(R.id.statusText);
            ivNoteImage = itemView.findViewById(R.id.ivNoteImage);
        }
    }
}
