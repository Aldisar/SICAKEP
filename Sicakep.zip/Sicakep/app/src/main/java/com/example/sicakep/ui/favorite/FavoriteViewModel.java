package com.example.sicakep.ui.favorite;

import androidx.lifecycle.ViewModel;

public class FavoriteViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}