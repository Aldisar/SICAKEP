package com.example.sicakep.ui.schedule;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sicakep.Catatan;
import com.example.sicakep.R;
import com.example.sicakep.ScheduleAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScheduleFragment extends Fragment {

    private RecyclerView recyclerView;
    private TextView emptyView;
    private Spinner spinnerFilter;
    private ScheduleAdapter scheduleAdapter;
    private List<Catatan> fullReminderList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_schedule, container, false);

        // Inisialisasi View
        recyclerView = view.findViewById(R.id.recyclerSchedule);
        emptyView = view.findViewById(R.id.emptyView);
        spinnerFilter = view.findViewById(R.id.spinnerFilter);
        Toolbar toolbar = view.findViewById(R.id.toolbar_schedule);
        TextView toolbarTitle = view.findViewById(R.id.toolbar_title_schedule);
        toolbarTitle.setText("Schedule");

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        scheduleAdapter = new ScheduleAdapter(getContext(), new ArrayList<>());
        recyclerView.setAdapter(scheduleAdapter);

        // Setup Spinner Filter
        spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selected = parent.getItemAtPosition(position).toString();
                filterData(selected);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Load Data
        ambilReminderDariFirebase();

        return view;
    }

    private void ambilReminderDariFirebase() {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("notes").child(userId);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                fullReminderList.clear();
                long now = System.currentTimeMillis();

                for (DataSnapshot ds : snapshot.getChildren()) {
                    Long reminderTime = ds.child("reminderTime").getValue(Long.class);
                    String title = ds.child("title").getValue(String.class);
                    String description = ds.child("description").getValue(String.class);
                    String imageBase64 = ds.child("imageBase64").getValue(String.class);
                    String kategori = ds.child("kategori").getValue(String.class);

                    if (reminderTime != null && reminderTime > 0) {
                        Catatan catatan = new Catatan(title, description, imageBase64, kategori, reminderTime);
                        catatan.setStatus(reminderTime > now ? "Akan Datang" : "Riwayat");
                        fullReminderList.add(catatan);
                    }
                }

                // Urutkan dari yang terbaru
                Collections.sort(fullReminderList, (a, b) -> Long.compare(b.getReminderTime(), a.getReminderTime()));

                // Terapkan filter berdasarkan pilihan spinner saat ini
                String currentFilter = spinnerFilter.getSelectedItem().toString();
                filterData(currentFilter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Gagal memuat pengingat", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void filterData(String filter) {
        List<Catatan> filtered = new ArrayList<>();
        for (Catatan catatan : fullReminderList) {
            if (filter.equals("Semua") || catatan.getStatus().equals(filter)) {
                filtered.add(catatan);
            }
        }

        if (filtered.isEmpty()) {
            emptyView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.GONE);
        }

        scheduleAdapter = new ScheduleAdapter(getContext(), filtered);
        recyclerView.setAdapter(scheduleAdapter);
    }
}
