package com.example.sicakep;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NoteFragment extends Fragment implements NoteAdapter.OnNoteActionListener {

    private ArrayList<Note> notes = new ArrayList<>();
    private boolean isGuest = false;
    private NoteAdapter noteAdapter;
    private RecyclerView recyclerView;
    private ImageView btnTambah;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_note, container, false);

        if (getArguments() != null) {
            isGuest = getArguments().getBoolean("isGuest", false);
        }

        recyclerView = view.findViewById(R.id.recyclerCatatan);
        btnTambah = view.findViewById(R.id.imgTambah);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        noteAdapter = new NoteAdapter(notes, this);
        recyclerView.setAdapter(noteAdapter);

        updateAddButtonVisibility();

        btnTambah.setOnClickListener(v -> {
            if (isGuest && notes.size() >= 3) {
                Toast.makeText(getContext(), "Guest hanya dapat membuat maksimal 3 catatan.", Toast.LENGTH_SHORT).show();
            } else {
                showCreateDialog();
            }
        });

        return view;
    }

    private void updateAddButtonVisibility() {
        if (isGuest && notes.size() >= 3) {
            btnTambah.setVisibility(View.GONE);
        } else {
            btnTambah.setVisibility(View.VISIBLE);
        }
    }

    private void showCreateDialog() {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_note_input, null);
        EditText inputJudul = dialogView.findViewById(R.id.editTextJudul);
        EditText inputKeterangan = dialogView.findViewById(R.id.editTextIsi);
        ImageView previewGambar = dialogView.findViewById(R.id.previewGambar);

        int[] gambarList = {R.drawable.ic_note, R.drawable.ic_note, R.drawable.ic_note};
        final int[] currentIndex = {0};
        previewGambar.setImageResource(gambarList[currentIndex[0]]);

        previewGambar.setOnClickListener(v -> {
            currentIndex[0] = (currentIndex[0] + 1) % gambarList.length;
            previewGambar.setImageResource(gambarList[currentIndex[0]]);
        });

        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setTitle("Tambah Catatan")
                .setView(dialogView)
                .setPositiveButton("Simpan", null)
                .setNegativeButton("Batal", null)
                .create();

        dialog.setOnShowListener(d -> {
            Button simpanBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            simpanBtn.setOnClickListener(v -> {
                String judul = inputJudul.getText().toString().trim();
                String keterangan = inputKeterangan.getText().toString().trim();

                if (judul.isEmpty() || keterangan.isEmpty()) {
                    Toast.makeText(getContext(), "Judul dan Keterangan wajib diisi", Toast.LENGTH_SHORT).show();
                } else if (isGuest && notes.size() >= 3) {
                    Toast.makeText(getContext(), "Guest hanya dapat membuat maksimal 3 catatan.", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                } else {
                    notes.add(new Note(judul, keterangan, gambarList[currentIndex[0]]));
                    noteAdapter.notifyItemInserted(notes.size() - 1);
                    dialog.dismiss();
                    updateAddButtonVisibility();
                }
            });
        });

        dialog.show();
    }

    private void showEditDialog(int position) {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_note_input, null);
        EditText inputJudul = dialogView.findViewById(R.id.editTextJudul);
        EditText inputKeterangan = dialogView.findViewById(R.id.editTextIsi);
        ImageView previewGambar = dialogView.findViewById(R.id.previewGambar);

        Note currentNote = notes.get(position);
        inputJudul.setText(currentNote.getJudul());
        inputKeterangan.setText(currentNote.getKeterangan());

        int[] gambarList = {R.drawable.ic_note, R.drawable.ic_note, R.drawable.ic_note};
        final int[] currentIndex = {0};
        for (int i = 0; i < gambarList.length; i++) {
            if (gambarList[i] == currentNote.getGambar()) {
                currentIndex[0] = i;
                break;
            }
        }

        previewGambar.setImageResource(gambarList[currentIndex[0]]);
        previewGambar.setOnClickListener(v -> {
            currentIndex[0] = (currentIndex[0] + 1) % gambarList.length;
            previewGambar.setImageResource(gambarList[currentIndex[0]]);
        });

        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setTitle("Edit Catatan")
                .setView(dialogView)
                .setPositiveButton("Simpan", null)
                .setNegativeButton("Batal", null)
                .create();

        dialog.setOnShowListener(d -> {
            Button simpanBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            simpanBtn.setOnClickListener(v -> {
                String judul = inputJudul.getText().toString().trim();
                String keterangan = inputKeterangan.getText().toString().trim();

                if (judul.isEmpty() || keterangan.isEmpty()) {
                    Toast.makeText(getContext(), "Judul dan Keterangan wajib diisi", Toast.LENGTH_SHORT).show();
                } else {
                    currentNote.setJudul(judul);
                    currentNote.setKeterangan(keterangan);
                    currentNote.setGambar(gambarList[currentIndex[0]]);
                    noteAdapter.notifyItemChanged(position);
                    dialog.dismiss();
                }
            });
        });

        dialog.show();
    }

    @Override
    public void onNoteClick(int position) {
        Note note = notes.get(position);
        Intent intent = new Intent(getContext(), DetailActivity.class);
        intent.putExtra("note", note);
        startActivity(intent);
    }

    @Override
    public void onEditClick(int position) {
        showEditDialog(position);
    }

    @Override
    public void onDeleteClick(int position) {
        notes.remove(position);
        noteAdapter.notifyItemRemoved(position);
        updateAddButtonVisibility();
    }
}
