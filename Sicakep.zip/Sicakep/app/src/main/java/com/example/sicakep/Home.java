package com.example.sicakep;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.sicakep.ui.home.HomeFragment;
import com.example.sicakep.ui.favorite.FavoriteFragment;
import com.example.sicakep.ui.Account.AccountFragment;
import com.example.sicakep.ui.schedule.ScheduleFragment; // ✅ Tambahkan ScheduleFragment
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class Home extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        bottomNavigationView = findViewById(R.id.bottom_navigation);

        // ✅ Tampilkan default HomeFragment saat pertama kali dibuka
        loadFragment(new HomeFragment());

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                int id = item.getItemId();

                if (id == R.id.menu_home) {
                    selectedFragment = new HomeFragment();
                } else if (id == R.id.menu_schedule) {
                    selectedFragment = new ScheduleFragment();
                } else if (id == R.id.menu_favorite) {
                    selectedFragment = new FavoriteFragment();
                } else if (id == R.id.menu_account) {
                    selectedFragment = new AccountFragment();
                }


                if (selectedFragment != null) {
                    loadFragment(selectedFragment);
                    return true;
                }
                return false;
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
