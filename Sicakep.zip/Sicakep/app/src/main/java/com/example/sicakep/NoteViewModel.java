package com.example.sicakep;

import androidx.lifecycle.ViewModel;

public class NoteViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}