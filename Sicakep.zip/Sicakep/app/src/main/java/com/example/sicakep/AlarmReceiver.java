package com.example.sicakep;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String noteId = intent.getStringExtra("noteId");

        // Kirim broadcast yang bisa diterima oleh komponen lain (HomeFragment)
        Intent popupIntent = new Intent("com.example.sicakep.NOTIF_HOME");
        popupIntent.putExtra("noteId", noteId);

        // Tambahkan flag agar broadcast bisa diterima di Android 12+
        popupIntent.setFlags(Intent.FLAG_RECEIVER_FOREGROUND);
        context.sendBroadcast(popupIntent);
    }
}
