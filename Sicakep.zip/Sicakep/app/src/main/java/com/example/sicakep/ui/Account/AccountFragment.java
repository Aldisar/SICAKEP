package com.example.sicakep.ui.Account;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.sicakep.ChangePasswordActivity;
import com.example.sicakep.EditProfileActivity;
import com.example.sicakep.EditProfileImageActivity;
import com.example.sicakep.LoginActivity;
import com.example.sicakep.R;
import com.example.sicakep.ui.favorite.FavoriteFragment;
import com.example.sicakep.ui.home.HomeFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AccountFragment extends Fragment {

    private FirebaseAuth mAuth;
    private TextView tvFullname, tvUsername, tvEmail, tvMyFavorite;
    private ImageView btnLogout, ivProfileImage;
    private Button btnEditProfile, btnChangePassword;
    private LinearLayout btnCatatanKu, btnMyFavorite;

    public AccountFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account, container, false);

        mAuth = FirebaseAuth.getInstance();

        // Inisialisasi view
        tvFullname = view.findViewById(R.id.tv_fullname);
        tvUsername = view.findViewById(R.id.tv_username);
        tvEmail = view.findViewById(R.id.tv_email);
        btnLogout = view.findViewById(R.id.btn_logout);
        btnEditProfile = view.findViewById(R.id.btn_edit_profile);
        btnChangePassword = view.findViewById(R.id.btn_change_password);
        btnCatatanKu = view.findViewById(R.id.btn_catatanku);
        btnMyFavorite = view.findViewById(R.id.btn_my_favorite);
        tvMyFavorite = view.findViewById(R.id.tv_my_favorite); // ini TextView My Favorite
        ivProfileImage = view.findViewById(R.id.profile_image);

        // Tampilkan data pengguna
        setUpUserData();

        // Tampilkan gambar profil dari Base64 Firebase
        showProfileImage();

        // Klik gambar profil → ke EditProfileImageActivity
        ivProfileImage.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), EditProfileImageActivity.class);
            startActivity(intent);
        });

        // Logout
        btnLogout.setOnClickListener(v -> logoutUser());

        // Klik CatatanKu → HomeFragment
        btnCatatanKu.setOnClickListener(v -> {
            FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container, new HomeFragment());
            transaction.addToBackStack(null);
            transaction.commit();
        });

        // Klik Edit Profile
        btnEditProfile.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), EditProfileActivity.class);
            intent.putExtra("username", tvUsername.getText().toString());
            intent.putExtra("email", tvEmail.getText().toString());
            intent.putExtra("fullname", tvFullname.getText().toString());
            startActivityForResult(intent, 100);
        });

        // Klik Change Password
        btnChangePassword.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), ChangePasswordActivity.class);
            startActivity(intent);
        });

        // Klik My Favorite (baik klik CardView atau TextView)
        btnMyFavorite.setOnClickListener(v -> openFavoriteFragment());
        tvMyFavorite.setOnClickListener(v -> openFavoriteFragment());

        return view;
    }

    private void openFavoriteFragment() {
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, new FavoriteFragment());
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private void setUpUserData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String uid = currentUser.getUid();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(uid);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String fullname = snapshot.child("fullname").getValue(String.class);
                        String username = snapshot.child("username").getValue(String.class);
                        String email = snapshot.child("email").getValue(String.class);

                        tvFullname.setText(fullname != null ? fullname : "Nama Lengkap");
                        tvUsername.setText(username != null ? username : "Nama Pengguna");
                        tvEmail.setText(email != null ? email : "email@example.com");
                    } else {
                        Toast.makeText(getContext(), "Data pengguna tidak ditemukan", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(getContext(), "Gagal memuat data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(getContext(), "User tidak login", Toast.LENGTH_SHORT).show();
        }
    }

    private void logoutUser() {
        mAuth.signOut();
        Intent intent = new Intent(getContext(), LoginActivity.class);
        startActivity(intent);
        requireActivity().finish();
    }

    private void showProfileImage() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;
        String userId = user.getUid();

        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);
        userRef.child("profileImage").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String base64 = snapshot.getValue(String.class);
                if (base64 != null && !base64.isEmpty()) {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    ivProfileImage.setImageBitmap(bitmap);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Tidak perlu apa-apa
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == getActivity().RESULT_OK && data != null) {
            String newFullname = data.getStringExtra("fullname");
            String newUsername = data.getStringExtra("username");
            String newEmail = data.getStringExtra("email");

            if (newFullname != null) tvFullname.setText(newFullname);
            if (newUsername != null) tvUsername.setText(newUsername);
            if (newEmail != null) tvEmail.setText(newEmail);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        showProfileImage();
    }
}
