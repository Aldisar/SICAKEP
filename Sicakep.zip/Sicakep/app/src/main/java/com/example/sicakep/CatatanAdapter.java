package com.example.sicakep;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CatatanAdapter extends RecyclerView.Adapter<CatatanAdapter.CatatanViewHolder> {

    private Context context;
    private List<Catatan> catatanList;

    public CatatanAdapter(Context context, List<Catatan> catatanList) {
        this.context = context;
        this.catatanList = catatanList;
    }

    @NonNull
    @Override
    public CatatanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_catatan, parent, false);
        return new CatatanViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CatatanViewHolder holder, int position) {
        Catatan catatan = catatanList.get(position);
        holder.textJudul.setText(catatan.getJudul());

        // 🔥 Tampilkan hanya 2 kata di keterangan
        String[] words = catatan.getKeterangan().split("\\s+");
        String shortDescription = catatan.getKeterangan();
        if (words.length > 2) {
            shortDescription = words[0] + " " + words[1] + "...";
        }
        holder.textKeterangan.setText(shortDescription);

        // 🔥 Decode Base64 gambar
        String base64Image = catatan.getGambarBase64();
        if (base64Image != null && !base64Image.isEmpty()) {
            try {
                byte[] decoded = Base64.decode(base64Image, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                holder.imageCatatan.setImageBitmap(bmp);
            } catch (Exception e) {
                holder.imageCatatan.setImageResource(R.drawable.ic_placeholder);
            }
        } else {
            holder.imageCatatan.setImageResource(R.drawable.ic_placeholder);
        }

        // 🔥 Klik "Lihat"
        holder.btnLihat.setOnClickListener(v -> {
            Intent i = new Intent(context, ViewNoteActivity.class);
            i.putExtra("noteId", catatan.getNoteId());
            context.startActivity(i);
        });

        // 🔥 Klik "Hapus"
        holder.btnHapus.setOnClickListener(v -> hapusItem(position));

        // 🔥 Klik "Edit"
        holder.btnEdit.setOnClickListener(v -> {
            Intent i = new Intent(context, EditNoteActivity.class);
            i.putExtra("noteId", catatan.getNoteId());
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return catatanList.size();
    }

    public Catatan getItemAt(int position) {
        return position >= 0 && position < catatanList.size()
                ? catatanList.get(position)
                : null;
    }

    public void hapusItem(int position) {
        catatanList.remove(position);
        notifyItemRemoved(position);
        Toast.makeText(context, "Catatan dihapus", Toast.LENGTH_SHORT).show();
    }

    public void editItem(int position) {
        notifyItemChanged(position);
        Toast.makeText(context, "Edit: " + catatanList.get(position).getJudul(),
                Toast.LENGTH_SHORT).show();
    }

    public void setFilteredList(List<Catatan> filteredList) {
        this.catatanList = filteredList;
        notifyDataSetChanged();
    }

    static class CatatanViewHolder extends RecyclerView.ViewHolder {
        ImageView imageCatatan;
        TextView textJudul, textKeterangan;
        Button btnLihat, btnHapus, btnEdit;

        CatatanViewHolder(@NonNull View itemView) {
            super(itemView);
            imageCatatan   = itemView.findViewById(R.id.imageCatatan);
            textJudul      = itemView.findViewById(R.id.textJudul);
            textKeterangan = itemView.findViewById(R.id.textKeterangan);
            btnLihat       = itemView.findViewById(R.id.btnLihat);
            btnHapus       = itemView.findViewById(R.id.btnHapus);
            btnEdit        = itemView.findViewById(R.id.btnEdit);
        }
    }
}
