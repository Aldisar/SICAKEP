package com.example.sicakep;

public class Catatan {
    private String noteId;
    private String judul;
    private String keterangan;
    private String gambarBase64;
    private String kategori;
    private long reminderTime;
    private int reminderCount;
    private String status; // ✅ Tambahan properti status

    public Catatan() {
    }

    // Konstruktor tanpa reminderTime
    public Catatan(String judul, String keterangan, String gambarBase64, String kategori) {
        this.judul = judul;
        this.keterangan = keterangan;
        this.gambarBase64 = gambarBase64;
        this.kategori = kategori;
        this.reminderTime = 0;
        this.reminderCount = 0;
    }

    // Konstruktor dengan reminderTime
    public Catatan(String judul, String keterangan, String gambarBase64, String kategori, long reminderTime) {
        this.judul = judul;
        this.keterangan = keterangan;
        this.gambarBase64 = gambarBase64;
        this.kategori = kategori;
        this.reminderTime = reminderTime;
        this.reminderCount = 0;
    }

    // Getter & Setter
    public String getNoteId() {
        return noteId;
    }

    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public String getGambarBase64() {
        return gambarBase64;
    }

    public void setGambarBase64(String gambarBase64) {
        this.gambarBase64 = gambarBase64;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public long getReminderTime() {
        return reminderTime;
    }

    public void setReminderTime(long reminderTime) {
        this.reminderTime = reminderTime;
    }

    public int getReminderCount() {
        return reminderCount;
    }

    public void setReminderCount(int reminderCount) {
        this.reminderCount = reminderCount;
    }

    // ✅ Getter & Setter untuk status
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
