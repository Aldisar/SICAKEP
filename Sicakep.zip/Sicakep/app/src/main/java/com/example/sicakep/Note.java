package com.example.sicakep;

import android.os.Parcel;
import android.os.Parcelable;

public class Note implements Parcelable {
    private String judul;
    private String keterangan;
    private int gambar;

    public Note(String judul, String keterangan, int gambar) {
        this.judul = judul;
        this.keterangan = keterangan;
        this.gambar = gambar;
    }

    protected Note(Parcel in) {
        judul = in.readString();
        keterangan = in.readString();
        gambar = in.readInt();
    }

    public static final Creator<Note> CREATOR = new Creator<Note>() {
        @Override
        public Note createFromParcel(Parcel in) {
            return new Note(in);
        }

        @Override
        public Note[] newArray(int size) {
            return new Note[size];
        }
    };

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public int getGambar() {
        return gambar;
    }

    public void setGambar(int gambar) {
        this.gambar = gambar;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(judul);
        parcel.writeString(keterangan);
        parcel.writeInt(gambar);
    }
}
